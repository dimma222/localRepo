class Admin::CustomerService::BaseController < Admin::BaseController

end
