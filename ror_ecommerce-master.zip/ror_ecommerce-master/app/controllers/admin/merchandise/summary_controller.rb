class Admin::Merchandise::SummaryController < Admin::BaseController
  def index

  end
end
