class Admin::Generic::BaseController < Admin::BaseController

end