class Admin::Config::OverviewsController < Admin::Config::BaseController
  # GET /admin/config/overviews
  def index

  end

end
