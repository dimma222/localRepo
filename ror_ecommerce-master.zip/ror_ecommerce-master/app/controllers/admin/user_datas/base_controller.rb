class Admin::UserDatas::BaseController < Admin::BaseController

end
