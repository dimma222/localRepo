class Admin::HelpController < Admin::BaseController
  def index
  end
end
