class CouponFirstPurchasePercent < CouponPercent
  include CouponFirstPurchase
end
