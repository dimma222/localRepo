class AddActiveToProducts < ActiveRecord::Migration[4.2]
  def change
    #add_column :products, :active, :boolean, :default => false
  end
end
